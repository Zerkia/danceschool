<?php
	define('__IncFolder__', 'includes');