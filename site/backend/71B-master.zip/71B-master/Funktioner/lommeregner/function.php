<?php

	function plus($x, $y){
		return $x + $y;
	}

	echo plus(5, 10);